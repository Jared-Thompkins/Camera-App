//
//  Camera_AppApp.swift
//  Camera-App
//
//  Created by Jared Thompkins on 11/22/23.
//

import SwiftUI

@main
struct Camera_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
